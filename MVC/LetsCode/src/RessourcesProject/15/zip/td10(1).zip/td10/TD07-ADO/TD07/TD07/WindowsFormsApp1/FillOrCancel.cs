﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;


namespace WindowsFormsApp1
{
    public partial class FillOrCancel : Form
    {
        private int ParsedOrderID;

        public object Propreties { get; private set; }

        public FillOrCancel()
        {
            InitializeComponent();
        }
        private bool IsOrderIDValid()
        {
            if (txtOrderID.Text == "")
            {
                MessageBox.Show("Please specifu the Order ID.");
                return false;   

            }
            else if (Regex.IsMatch(txtOrderID.Text, @"^\D*$"))
            {
                MessageBox.Show("Customer ID must contain Only numbers.");
                txtOrderID.Clear();
                return false;
            }
            else
            {
                ParsedOrderID = Int32.Parse(txtOrderID.Text);
                return true;
            }
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void FillOrCancel_Load(object sender, EventArgs e)
        {

        }

        private void btnFindByOrderID_Click(object sender, EventArgs e)
        {
            if (IsOrderIDValid())
            {
                using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connString))
                {
                    const string sql = "Select * From Sales.Orders WHERE orderID=@orderID";
                    using (SqlCommand sqlCommand = new SqlCommand(sql, connection))
                    {
                        sqlCommand.Parameters.Add(new SqlParameter("@orderID", SqlDbType.Int));
                        sqlCommand.Parameters["@orderID"].Value = ParsedOrderID;
                        try
                        {
                            connection.Open();
                            using(SqlDataReader datareader = sqlCommand.ExecuteReader())
                            {
                                DataTable datable=new DataTable();
                                datable.Load(datareader);
                                this.dgvCustomerOrders.DataSource = datable;    
                                datareader.Close();

                            }
                        }
                        catch
                        {
                            MessageBox.Show("erreur");

                        }
                        finally
                        {
                            connection.Close();
                        }


                    }
                }
            }
        }

        private void btnCancelOrder_Click(object sender, EventArgs e)
        {

        }

        private void btnFillOrder_Click(object sender, EventArgs e)
        {

        }

        private void btnFinishUpdates_Click(object sender, EventArgs e)
        {

        }
    }
}
