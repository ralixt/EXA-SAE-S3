﻿using System.Collections.Generic;

namespace JeuCartes
{
    public class Hand
    {
        private List<PlayingCard> cards;

        public Hand()
        {
            cards = new List<PlayingCard>();
        }

        public void addCard(PlayingCard pc)
        {
            cards.Add(pc);
        }

        public PlayingCard getCard(int index)
        {
            return cards[index];
        }

        public PlayingCard removeCard()
        {
            PlayingCard pc = cards[0];
            cards.RemoveAt(0);
            return pc;
        }
    }
}
