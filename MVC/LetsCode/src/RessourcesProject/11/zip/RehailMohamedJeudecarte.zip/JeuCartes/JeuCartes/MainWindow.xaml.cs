﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JeuCartes
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, GameIView
    {
        private GameController controller;
        

        
        public MainWindow()
        {
            InitializeComponent();
            GameController gc = new GameController(new Deck(), this);
            
        }
        public void ExecuteCommand()
        {
            controller.run(ReadLine());
        }

        public void promptForFlip()
        {
            WriteLine("Press <Jouer> to reveal cards");
        }
        public void ClearInput()
        {
            AjoutJoueur fen = new AjoutJoueur();
            fen.ajoutjoueur.Clear();
        }

        public void ClearOutput()
        {
            output.Clear();
        }
        public string ReadLine()
        {
            AjoutJoueur fen = new AjoutJoueur();
            string name = fen.ajoutjoueur.Text;
            ClearInput();
            return name;
        }
        public void promptForNewGame()
        {
            WriteLine("Press <Jouer> to deal again");
        }

        public void promptForPlayerName()
        {
            // WriteLine("Enter Player Name.");
          
           AjoutJoueur fen = new AjoutJoueur();
            
            Player p = new Player(fen.ajoutjoueur.Text);
            // string a = fen.ajoutjoueur.Text.ToString();
            if (fen.ShowDialog() == true)
            {
                controller.addPlayer(fen.ajoutjoueur.Text);
                PrintList();
            }
        }

        public void setController(GameController gc)
        {
            controller = gc;
        }

        public void showCardForPlayer(int i, string playerName, string rank, string suit)
        {
            WriteLine("[" + i + "][" + playerName + "][" + rank + "][" + suit + "]");
        }

        public void showFaceDownCardForPlayer(int i, string playerName)
        {
            WriteLine("[" + i + "][" + playerName + "][x][x]");
        }

        public void showPlayerName(int playerIndex, string playerName)
        {
            WriteLine("[" + playerIndex + "][" + playerName + "]");
        }

        public void showWinner(string playerName)
        {
            WriteLine("Winner is " + playerName + " !");
        }
        public void WriteLine(string msg)
        {
            output.Text += msg + "\n";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            promptForPlayerName();
        }

        public void PrintList()
        {
            
            ajout.Items.Clear(); // clear existings items
            List<Player> list = controller.Listplayers();
            foreach (Player p in list)
            {
                ajout.Items.Add(p.Name);
              //  output.Text += p.Name;
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ExecuteCommand();
        }
    }
}
