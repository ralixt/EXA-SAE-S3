﻿using System;
using System.Collections.Generic;

namespace JeuCartes
{
    public class Deck
    {
        private List<PlayingCard> cards;

        public Deck()
        {
            cards = new List<PlayingCard>();
            foreach (Rank rank in Enum.GetValues(typeof(Rank)))
            {
                foreach (Suit suit in Enum.GetValues(typeof(Suit)))
                {
                    //Console.WriteLine("Creating card [" + rank + "][" + suit + "]");
                    cards.Add(new PlayingCard(rank, suit));
                }
            }
            shuffle();
        }

        public void shuffle()
        {
            Random random = new Random();
            for (int i = 0; i < cards.Count; i++)
            {
                PlayingCard temp = cards[i];
                int j = random.Next(cards.Count);
                cards[i] = cards[j];
                cards[j] = temp;
            }
        }
        public PlayingCard removeTopCard()
        {
            PlayingCard pc = cards[0];
            cards.RemoveAt(0);
            return pc;
        }
        public void returnCardToDeck(PlayingCard pc)
        {
            cards.Add(pc);
        }
        public List<PlayingCard> getCards()
        {
            return cards;
        }
    }
}
