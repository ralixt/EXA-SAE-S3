﻿using System;

namespace JeuCartes
{
    /// <summary>
    /// Simple interface to a text console
    /// </summary>
    interface IView
    {
        /// <summary>
        /// write a message
        /// </summary>
        /// <param name="msg">the message to write</param>
        void Write(string msg);
        /// <summary>
        /// Write the message, than do a carridge return and a line feed
        /// </summary>
        /// <param name="msg">the message to write</param>
        void WriteLine(string msg);
        /// <summary>
        /// Read a message from the keyboard
        /// </summary>
        /// <returns>the message typed by the user</returns>
        void ClearOutput();
        string ReadLine();
        void ClearInput();

        void promptForPlayerName();
        void promptForFlip();
        void promptForNewGame();
        void showWinner(String playerName);
        void showPlayerName(int playerIndex, String playerName);
        void showFaceDownCardForPlayer(int i, String playerName);
        void showCardForPlayer(int i, string playerName, string rank, string suit);
        void ExecuteCommand();
    }
}
