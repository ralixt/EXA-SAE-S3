﻿namespace JeuCartes
{
    public class PlayingCard
    {
        private readonly Rank rank;
        private readonly Suit suit;
        private bool faceUp;

        public Rank getRank()
        {
            return rank;
        }
        public Suit getSuit()
        {
            return suit;
        }
        public bool isFaceUp() { 
            return faceUp;        
        }
        public bool flip()
        {
            faceUp = !faceUp;
            return faceUp;
        }
        public PlayingCard(Rank rank, Suit suit)
        {
            this.rank = rank;
            this.suit = suit;
        }
    }
}
