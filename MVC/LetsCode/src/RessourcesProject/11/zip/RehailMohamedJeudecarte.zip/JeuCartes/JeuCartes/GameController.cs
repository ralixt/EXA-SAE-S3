﻿using System.Collections.Generic;

namespace JeuCartes
{
    public class GameController
    {
        enum GameState
        {
            AddingPlayers, CardsDealt, CardsRevealed, WinnerRevealed
        }
        Deck deck;
        List<Player> players;
        Player winner;
        GameIView view;
        GameState gameState;

        public GameController(Deck deck, GameIView view)
        {
            this.deck = deck;
            this.view = view;
            this.players = new List<Player>();
            this.gameState = GameState.AddingPlayers;
            view.setController(this);
            
            view.promptForPlayerName();
        }
        public List<Player> Listplayers()
        {
            return players;
        }

        public void run(string cmd)
        {
            switch (gameState)
            {
                case GameState.AddingPlayers:
                    if (cmd == "")
                    {
                        startGame();
                    }
                    else
                    {
                        addPlayer(cmd);
                        view.promptForPlayerName();
                    }
                    break;
                case GameState.CardsDealt:
                    gameState = GameState.CardsRevealed;
                    view.promptForFlip();
                    break;
                case GameState.CardsRevealed:
                    flipCards();
                    break;
                case GameState.WinnerRevealed:
                    gameState = GameState.AddingPlayers;
                    view.promptForNewGame();
                    break;
            }
        }

        public void addPlayer(string playerName)
        {
            if (gameState == GameState.AddingPlayers)
            {
                players.Add(new Player(playerName));
                view.showPlayerName(players.Count,playerName);
            }
        }

        public void startGame()
        {
            if (gameState != GameState.CardsDealt)
            {
                view.ClearOutput();
                deck.shuffle();
                int playerIndex = 1;
                foreach (Player player in players)
                {
                    player.addCardToHand(deck.removeTopCard());
                    view.showFaceDownCardForPlayer(playerIndex++, player.Name);
                }
                gameState = GameState.CardsDealt;
            }
            this.run("");
        }


        public void flipCards()
        {
            int playerIndex = 1;
            foreach (Player player in players)
            {
                PlayingCard pc = player.getCard(0);
                pc.flip();
                view.showCardForPlayer(playerIndex++, player.Name, pc.getRank().ToString(), pc.getSuit().ToString());
            }

            evaluateWinner();
            displayWinner();
            rebuildDeck();
            gameState = GameState.WinnerRevealed;
            this.run("");
        }

        void evaluateWinner()
        {
            Player bestPlayer = null;
            int bestRank = -1;
            int bestSuit = -1;

            foreach (Player player in players)
            {
                bool newBestPlayer = false;

                if (bestPlayer == null)
                {
                    newBestPlayer = true;
                }
                else
                {
                    PlayingCard pc = player.getCard(0);
                    int thisRank = (int)pc.getRank();
                    if (thisRank >= bestRank)
                    {
                        if (thisRank > bestRank)
                        {
                            newBestPlayer = true;
                        }
                        else
                        {
                            if ((int)pc.getSuit() > bestSuit)
                            {
                                newBestPlayer = true;
                            }
                        }
                    }
                }

                if (newBestPlayer)
                {
                    bestPlayer = player;
                    PlayingCard pc = player.getCard(0);
                    bestRank = (int)pc.getRank();
                    bestSuit = (int)pc.getSuit();
                }
            }

            winner = bestPlayer;
        }

        void displayWinner()
        {
            view.showWinner(winner.Name);
        }

        void rebuildDeck()
        {
            foreach (Player player in players)
            {
                deck.returnCardToDeck(player.removeCard());
            }
        }
    }
}
