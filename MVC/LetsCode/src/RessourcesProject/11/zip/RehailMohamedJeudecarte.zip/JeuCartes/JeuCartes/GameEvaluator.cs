﻿using System.Collections.Generic;

namespace JeuCartes
{
    public class GameEvaluator
    {
        public Player evaluateWinner(List<Player> players)
        {
            Player bestPlayer = null;
            int bestRank = -1;
            int bestSuit = -1;

            foreach (Player player in players)
            {
                bool newBestPlayer = false;

                if (bestPlayer == null)
                {
                    newBestPlayer = true;
                }
                else
                {
                    PlayingCard pc = player.getCard(0);
                    int thisRank = (int)pc.getRank();
                    if (thisRank >= bestRank)
                    {
                        if (thisRank > bestRank)
                        {
                            newBestPlayer = true;
                        }
                        else
                        {
                            if ((int)pc.getSuit() > bestSuit)
                            {
                                newBestPlayer = true;
                            }
                        }
                    }
                }

                if (newBestPlayer)
                {
                    bestPlayer = player;
                    PlayingCard pc = player.getCard(0);
                    bestRank = (int)pc.getRank();
                    bestSuit = (int)pc.getSuit();
                }
            }

            return bestPlayer;
        }
    }
}
