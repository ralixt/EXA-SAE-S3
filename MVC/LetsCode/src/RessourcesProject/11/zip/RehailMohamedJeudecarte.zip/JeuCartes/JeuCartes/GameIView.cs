﻿namespace JeuCartes
{
    public interface GameIView
    {
        void setController(GameController gc);
        void promptForPlayerName();
        void promptForFlip();
        void PrintList();
        void ClearOutput();
        void ClearInput();
        string ReadLine();

        void promptForNewGame();
        void showWinner(string playerName);
        void showPlayerName(int playerIndex, string playerName);
        void showFaceDownCardForPlayer(int i, string playerName);
        void showCardForPlayer(int i, string playerName, string rank, string suit);
    }
}
