using JeuCartes;

namespace TestJeuCartes
{
    public class TestPlayingCard
    {
        [Fact]
        public void TestProperties()
        {
            PlayingCard pc = new PlayingCard(Rank.ACE, Suit.DIAMONDS);
            Assert.Equal(Rank.ACE, pc.getRank());
            Assert.Equal(Suit.DIAMONDS, pc.getSuit());
        }
    }
}