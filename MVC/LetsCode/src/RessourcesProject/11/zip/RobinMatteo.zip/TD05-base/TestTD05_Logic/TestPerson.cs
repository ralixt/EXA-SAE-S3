using TD05;
namespace TestTD05_Logic
{
    public class TestPerson
    {
        [Fact]
        public void TestClone()
        {
            Person person = new Person() { LastName = "Dickinson", FirstName = "Bruce", Gender = Gender.MALE };
            Assert.Equal(person, person.Clone());
        }
    }
}