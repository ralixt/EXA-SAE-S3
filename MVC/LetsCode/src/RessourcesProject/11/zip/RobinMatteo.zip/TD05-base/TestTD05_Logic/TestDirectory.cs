﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TD05;

namespace TestTD05_Logic
{
    public class TestDirectory
    {
        [Fact]
        public void TestList()
        {
      
        }

        [Fact]
        public void TestAdd()
        {
            Person person = new Person() { LastName = "Dickinson", FirstName = "Bruce", Gender = Gender.MALE };
            TD05.Directory directory = new TD05.Directory();
            directory.Add(person);
            Person[] ar = directory.ListAll();
            Assert.Equal(1, ar.Length);

        }
    }
}
