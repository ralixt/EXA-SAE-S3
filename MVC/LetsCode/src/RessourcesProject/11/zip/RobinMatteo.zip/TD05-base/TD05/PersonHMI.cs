﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace TD05
{
    public class PersonHMI :IPerson, ICloneable
    {
        private Person person;
        readonly private BitmapImage icon;

        public PersonHMI (Person person)
        {
            this.person = person;
            if(person.Gender == Gender.MALE)
            {
                icon = new BitmapImage(new Uri("pack://application:,,,/TD05;component/images/contact_m.png"));
            }
            else if (person.Gender == Gender.FEMALE)
            {
                icon = new BitmapImage(new Uri("pack://application:,,,/TD05;component/images/contact_f.png"));
            }
            else
            {
                icon = new BitmapImage(new Uri("pack://application:,,,/TD05;component/images/contact_x.png"));
            }
        }


        public BitmapImage Icon { get { return icon; } }
        public string Address { get => ((IPerson)person).Address; set => ((IPerson)person).Address = value; }
        public string EMail { get => ((IPerson)person).EMail; set => ((IPerson)person).EMail = value; }
        public string FirstName { get => ((IPerson)person).FirstName; set => ((IPerson)person).FirstName = value; }
        public Gender Gender { get => ((IPerson)person).Gender; set => ((IPerson)person).Gender = value; }
        public string LastName { get => ((IPerson)person).LastName; set => ((IPerson)person).LastName = value; }
        public string Phone { get => ((IPerson)person).Phone; set => ((IPerson)person).Phone = value; }
        public Person Person { get => person; }

        public void Copy(Person p)
        {
            ((IPerson)person).Copy(p);
        }

        public object Clone()
        {
            return ((ICloneable)person).Clone();
        }

        public bool IsMale
        {
            get { return Gender == Gender.MALE; }
            set { if (value) Gender = Gender.MALE; }
        }

        public bool IsFemale
        {
            get { return Gender == Gender.FEMALE; }
            set { if (value) Gender = Gender.FEMALE; }
        }
    }
}
