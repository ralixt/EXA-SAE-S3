﻿using System;

namespace serialisation
{
    public class Class1
    {

    }
}
