﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;


namespace TD05
{
    public class PersonHMI:IPerson,ICloneable
    {
        Person p1=new Person();
        BitmapImage Icon = new BitmapImage();

        public BitmapImage icon { get { return Icon; } }

        
        public PersonHMI(Person p1)
        {
            this.p1 = p1;
            if (p1.Gender == Gender.MALE)
            {
                this.Icon = new BitmapImage(new Uri("pack://application:,,,/TD05;component/images/contact_m.png"));
            }
            else if (p1.Gender == Gender.FEMALE)
            {
                this.Icon = new BitmapImage(new Uri("pack://application:,,,/TD05;component/images/contact_f.png"));
            }
            else
            {
                this.Icon = new BitmapImage(new Uri("pack://application:,,,/TD05;component/images/contact_x.png")); 
            }

        }
        

        public string Address { get => ((IPerson)p1).Address; set => ((IPerson)p1).Address = value; }
        public string EMail { get => ((IPerson)p1).EMail; set => ((IPerson)p1).EMail = value; }
        public string FirstName { get => ((IPerson)p1).FirstName; set => ((IPerson)p1).FirstName = value; }
        public Gender Gender { get => ((IPerson)p1).Gender; set => ((IPerson)p1).Gender = value; }
        public string LastName { get => ((IPerson)p1).LastName; set => ((IPerson)p1).LastName = value; }
        public string Phone { get => ((IPerson)p1).Phone; set => ((IPerson)p1).Phone = value; }

        public object Clone()
        {
            return ((ICloneable)p1).Clone();
        }

        public void Copy(Person p)
        {
            ((IPerson)p1).Copy(p);
        }
        public Person getPerson
        {
            get{ return this.p1; }
        }
        public bool IsMale
        {
            get { return Gender == Gender.MALE; }
            set { if(value)  Gender = Gender.MALE; }
        }
        public bool IsFemale
        {
            get { return Gender == Gender.FEMALE; }
            set { if (value) Gender = Gender.FEMALE; }
        }
    }
}
