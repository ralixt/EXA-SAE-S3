﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Text;
using TD05;
using TD05_logic;

namespace serialisation
{
    public class JsonStorage : IStorage
    {
        public string file;
        public TD05.Directory dir;

        public JsonStorage(string file , TD05.Directory dir)
        {
            this.file = file;
            this.dir = dir;

        }

        Person IStorage.Create(Person p)
        {
            new Person() ;
        }

        public void Delete(Person p)
        {
            throw new NotImplementedException();
        }

        public TD05.Directory Load()
        {
            try
            {
                using(FileStream flux =new FileStream(file, FileMode.Open))
                {
                    DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(TD05.Directory));
                    dir= (TD05.Directory)ser.ReadObject(flux) as TD05.Directory;
                }
            }
            catch
            {
                dir = new TD05.Directory();
            }
            return dir;
        }

        public void Update()
        {
            throw new NotImplementedException();
        }
        public void Save()
        {
            FileStream flux =new FileStream(file, FileMode.Open);
            DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(TD05.Directory));
            ser.ReadObject(flux);
        }
        
    }
}
