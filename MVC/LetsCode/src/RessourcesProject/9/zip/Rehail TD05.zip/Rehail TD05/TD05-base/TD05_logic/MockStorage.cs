﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TD05;

namespace TD05_logic
{
    public class MockStorage : IStorage
    {
        
        public Person Create()
        {
            return new Person();
        }

        public void Delete()
        {
            
        }
       
        public Directory Load()
        {
             Directory a = new Directory();

            a.Add(new Person() { LastName = "Dickinson", FirstName = "Bruce", Gender = Gender.MALE });
            a.Add(new Person() { LastName = "Jansen", FirstName = "Floor", Gender = Gender.FEMALE });
            return a;
        }
       

        public void Update()
        {
             

          
        }
    }
}
