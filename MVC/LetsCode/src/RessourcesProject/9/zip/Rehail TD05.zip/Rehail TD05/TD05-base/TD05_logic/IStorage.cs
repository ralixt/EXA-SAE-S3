﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TD05;

namespace TD05_logic
{
    public interface IStorage
    {
         Person Create(Person p);
         void  Update();
        void Delete(Person p);
        Directory Load();


    }
}
