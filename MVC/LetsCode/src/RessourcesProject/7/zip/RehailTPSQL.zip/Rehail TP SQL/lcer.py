# lcer.py
# chapitre 5, TP

# Ce fichier est le squelette d'une interface textuelle pour appeler les différentes
# fonctions à écrire dans le TP, il est à compléter. 
# Dans la version présente ces fonctions sont définies en début de fichier (elles
# sont vides, elles sont à écrire dans le TP). On peut les organiser ainsi, ou les
# regrouper dans un autre fichier dédié, qui pourra être importé depuis le présent
# fichier ou le fichier interface graphique. 

# tourne avec python3.10

#########################################################################################
# Ce menu contient les 5 fonctions à écrire dans le TP. Toutes les autres manipulations
# sont faites par l'utilisateur dans un client interactif : les fonctionnalités demandées
# dans le TP, et aussi les interrogations de la base (utiles aussi pour débuguer). 
import sqlite3
def relance():
    print("Ici la fonction relance.")
    cnx=sqlite3.connect('lcer.db')
    c=cnx.cursor()
    c.execute("Select * from client where debit!=0;")
    l=c.fetchall()
    for i in range(len(l)):
        print ("Bonjour ",l[i][1], " Vous nous devez une somme de  ",l[i][4]," ")
        cnx.close()

def analyse():
    print("Ici la fonction analyse.")
    cnx=sqlite3.connect('lcer.db')
    s=input("le nom du client")
    motif=[s]
    c=cnx.cursor()
    c.execute('''Select Sum(prix) from produit join achat on produit.idp=achat.idp 
              join client on achat.idc=client.idc where client.nom=? ''',motif)
   
    r=c.fetchall()
    
    print("la somme des achat pour ce client est de",r[0][0],'\n')
    cnx.close()  
    
def expedition():
    print("Ici la fonction expedition.") 
    cnx=sqlite3.connect('lcer.db')
    c=cnx.cursor()
    c.execute("Select idp from Achat where expedie='non'")
    l=c.fetchall()
  

    if (l[0][0]!=""):
        idps=[l[0][0]]
        c.execute('''Update Produit
                        set stock=stock-1 where idp=?''',idps )
        
    
        l=c.fetchall()
        #print(l[0][0])
        c.execute('''Update Achat set expedie='non' where idp=? ''',(idps))
        l=c.fetchall()
        c.execute('''select stock from produit where idp=? ''',(idps))
        l=c.fetchall()
        for i in range(len(l)):
            print("le nouveau numéro de stock est ",l[i][0] )
    cnx.close()

def achat():
    print("Ici la fonction achat.")
    cnx=sqlite3.connect('lcer.db')
    s=input("le nom du client : ")
    num=int(input("L'identifiant du client :"))
    nums=[num]
    motif=[num,s];

    c=cnx.cursor()
    c.execute(''' Select * from client where client.idc=? AND client.nom=? ''',motif)
    l=c.fetchall()

    if l[0][0]!="":
        numProduit=int(input("le num du produit : "))
        motif2=[numProduit]
        numAchat= int(input("le numéro  d'chat' : "))    
        motif3=[numAchat]
        c.execute('''Select Prix from produit where produit.idp=?''',motif2)
        l=c.fetchall()

        prix=l[0][0]
        r=[prix]

        c.execute(''' insert into Achat values (?,?,?,'non') ''',(numAchat,numProduit,num))
        l=c.fetchall()




        c.execute('''Update Client
                        set debit=debit+? where idc=?''',(prix,num) )
        l=c.fetchall()
        c.execute('''Select debit from Client
                             where idc=?''', ( nums))
        l = c.fetchall()
        print( "Votre débit est actuellement de : ",l[0][0])
        cnx.close()
    
def paiement():
    print("Ici la fonction paiement.")
    cnx=sqlite3.connect('lcer.db')
    
    num=int(input("L'identifiant du client :"))
    nums=[num]
    c=cnx.cursor()
    c.execute(''' Select debit from Client where idc=?''',nums)
    l=c.fetchall()
    while l[0][0]!=0:
        print("Votre débit est actuellement de : ",l[0][0])
        argent=int(input("rentrer le montant que voulez-vous régler :"))
        if(argent<=l[0][0]):
            c.execute('''Update client
                            set debit=debit-? where idc=?''',(argent,num) )
            
            l=c.fetchall()
            c.execute(''' Select debit from Client where idc=?''',nums)
            l=c.fetchall()
        print("Votre débit actuelle est de: ",l[0][0])
def menu():
    while True:
        print("""\
------------------------------------------
Bienvenue chez LCER
Entrez un entier :
  0 : Sortir du menu et du programme
Menu dirigeant :
  1 : Relance pour le paiement d'un débit
  2 : Analyse des ventes
  3 : Expédition d'un achat
Menu clients :
  4 : Achat d'un produit
  5 : Paiement du débit
------------------------------------------
""")
        n = int(input('Entrez votre choix : '))
        if n == 0:
            return
        elif n == 1:
            relance()
        elif n == 2:
            analyse()
        elif n == 3:
            expedition()
        elif n == 4:
            achat()
        elif n == 5:
            paiement()
        else:
            print('Choix non disponible')

# termios peut être utilisé sur Linux mais pas avec Windows
#import termios
import sys
#print(termios.tcgetattr(sys.stdin))

menu()

###############################################################################
