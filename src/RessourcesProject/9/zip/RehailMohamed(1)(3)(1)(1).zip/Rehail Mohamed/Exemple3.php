
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="stylesss.css">
    <title>Affichage des recettes</title>
    <h1>Liste de recette de cuisine</h1>
</head>
<div id='main'>
    <header>
    <?php include('Header.php'); ?>
    </header>
    <body>
        <?php include('function.php'); ?>
        <?php include('variable.php'); ?>

            <div class="container">
                
                <?php foreach($recipes as $recipe ):?>
                        <?php if(isValidRecipe($recipe)=='true'):?>
                        <?php $Mail=$recipe['author'];?>
                
                        <?php foreach($users as $user):?>
                                <?php if($Mail===$user['email']):?>
                                    <h2> <?php echo $recipe['title']?></h2>
                                    <?php echo ' Le nom est : '. $user['full_name'].'<br>';?>
                                <?php endif?>
                                
                            <?php endforeach?>
                        <?php endif?>
                    <?php endforeach?>
            

        
                    

            </div>   
    </body>
    <footer>
       
                    
        <?php include('Footer.php'); ?>
    </footer>
 </div>
</html>