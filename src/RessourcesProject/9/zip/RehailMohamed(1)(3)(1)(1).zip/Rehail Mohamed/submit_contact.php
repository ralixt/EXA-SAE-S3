<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="stylesss.css">
    <title>Affichage des recettes</title>
    
</head>
<div id='main'>
    <header>
 
    </header>
    <body>
    <h1> message bien reçu!</h1>
    <div class="contenair">
        <h5> Rappel de vos informations </h5>
        <p> Email: <?php echo $_GET['adr'];?></p>
        <p> Message: <?php echo $_GET['message'];?></p>
    </div> 
    </body>
    <footer>
       
    </footer>
 </div>
</html>