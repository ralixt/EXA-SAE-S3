<nav id="menu">        
    <div class="element_menu">
        <h2> Menu</h2>
        <ul>
            <li><a href="Exemple3.php">Recette</a></li>
            <li><a href="page2.html">Création recette</a></li>
            <li><a href="formulaire.php">Formulaire</a></li>
        </ul>
    </div>    
</nav>