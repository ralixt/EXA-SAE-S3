
                <fieldset>
                    <legend><strong>Contacter-nous</strong></legend>

                    <div>
                      <form action="submit_contact.php" method="GET">
                            <label for="adr_email">Email<span class="obligatoire">*</span> : </label>
                            <input id="adr_email" name="adr" type="email" placeholder="yourmail@domain.com" required>
                        </div>
                              
                              

                          <div>
                                  <label for="message_demande">Votre message : </label>
                                  <p>
                                      <textarea id ="message_demande" name="message" placeholder="Ecrivez votre message"></textarea>
                                  </p>
                          </div>
                          <br>
                            <input type="submit" value="Envoyer">
                      </form>
                </fieldset>

