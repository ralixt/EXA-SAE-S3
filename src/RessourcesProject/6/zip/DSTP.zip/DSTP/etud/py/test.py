import csv
import sqlite3
db = sqlite3.connect('./../univ.db')
cursor = db.cursor()
cursor.execute("SELECT codeMatiere, COUNT(idEtudiant) FROM inscription ORDER BY codeMatiere;")
nbEtud = cursor.fetchall()