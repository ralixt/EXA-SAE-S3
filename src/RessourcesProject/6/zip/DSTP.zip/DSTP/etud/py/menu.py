# menu.py
# R3.07 SQL dans un langage de programmation

# Ce fichier est le squelette d'une interface textuelle pour appeler les différentes
# fonctions à écrire dans le DSTP, il est à compléter. 
# Dans la version présente ces fonctions sont définies en début de fichier (elles
# sont vide, elles sont à écrire dans le DSTP). On peut les organiser ainsi, ou les
# regrouper dans un autre fichier dédié, qui pourra être importé depuis le présent
# fichier ou le fichier interface graphique.
import csv
import sqlite3

def importInscription():
    with open('./../csv/inscriptions.csv') as csvfile:
        csvObject = csv.reader(csvfile, delimiter=';')
        data = list(csvObject)
    data.pop(0)
    
    fichier = open("./../sql/inscriptions.sql","w")
    fichier.write("DROP TABLE IF EXISTS inscription;\n")
    fichier.write("CREATE TABLE inscription (idInscription INTEGER, idEtudiant INTEGER , codeMatiere CHAR(4), PRIMARY KEY (idInscription), FOREIGN KEY (idEtudiant) REFERENCES etudiant(idEtudiant), FOREIGN KEY (codeMatiere) REFERENCES matiere(codeMatiere));\n")
    for i in data:
        fichier.write("INSERT INTO inscription VALUES (" + i[0] + "," + i[1] + ",'" + i[2] + "'); \n")
    
    fichier.close()

def importResultat():
    with open('./../csv/resultats.csv') as csvfile:
        csvObject = csv.reader(csvfile, delimiter=';')
        data = list(csvObject)
    data.pop(0)

    fichier = open("./../sql/resultats.sql","w")
    fichier.write("DROP TABLE IF EXISTS resultat;\n")
    fichier.write("CREATE TABLE resultat (idResultat INTEGER, idInscription INTEGER , note DECIMAL(2.2), PRIMARY KEY (idResultat), FOREIGN KEY (idInscription) REFERENCES inscription(idInscription));\n")
    for i in data:
        fichier.write("INSERT INTO resultat VALUES (" + i[0] + "," + i[1] + "," + i[2] + "); \n")

    fichier.close()

def exportStat():
    db = sqlite3.connect('./../univ.db')
    cursor = db.cursor()
    cursor.execute("SELECT codeMatiere, COUNT(idEtudiant) FROM inscription:")
    nbEtud = cursor.fetchall()
    

def nouvelEtud():
    print("Ici la fonction nouvelEtud.")

def menu():
    while True:
        print("""\
------------------------------------------
Bienvenue à l'université
Entrez un entier :
  0 : Sortir du menu et du programme
  1 : Importer les inscriptions
  2 : Importer les résultats
  3 : Exporter les statistiques
  4 : Inscrire un nouvel étudiant
------------------------------------------
""")
        n = int(input('Entrez votre choix : '))
        if n == 0:
            return
        elif n == 1:
            importInscription()
        elif n == 2:
            importResultat()
        elif n == 3:
            exportStat()
        elif n == 4:
            nouvelEtud()
        else:
            print('Choix non disponible')

menu()

###############################################################################
