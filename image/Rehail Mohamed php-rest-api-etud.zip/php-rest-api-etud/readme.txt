DOCUMENTATION PHP CRUD API :
* Get- localhost/my-app/php-rest-api-etud/api/read-php : Récupère tout les recettes;
* Get- localhost/my-app/php-rest-api-etud/api/Single-read.php?recipe-id=2 : Récupère la recette qui a l'id=2;
* POST-localhost/my-app/php-rest-api-etud/api/create.php: Création de la recette
* POST-localhost/my-app/php-rest-api-etud/api/update.php: modification de la recette
* Delete-localhost/my-app/php-rest-api-etud/api/delete.php: suppression  de la recette 