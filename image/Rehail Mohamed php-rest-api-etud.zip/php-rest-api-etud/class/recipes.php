<?php
    class Recipe {
        // Connection
        private $conn;
        // Table
        private $db_table = "recipes";
        // Columns
        public $recipe_id;
        public $title;
        public $recipe;
        public $author;
        public $is_enabled;
        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }
        // GET ALL
        public function getRecipes(){
            $sqlQuery = "SELECT recipe_id, title, recipe, author,
            is_enabled FROM " . $this->db_table . "";
            $stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }
        // CREATE
        public function createRecipe(){
            $sqlQuery = "INSERT INTO
                        ". $this->db_table ."
                    SET
                        title = :title, 
                        recipe = :recipe, 
                        author = :author, 
                        is_enabled = :is_enabled";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            // bind data
            $stmt->bindParam(":title", $this->title);
            $stmt->bindParam(":recipe", $this->recipe);
            $stmt->bindParam(":author", $this->author);
            $stmt->bindParam(":is_enabled", $this->is_enabled);
            
            if($stmt->execute()){
               return true;
            }
            return false;
        }
        // READ single
        public function getSingleRecipe(){
            $sqlQuery = "SELECT
                        recipe_id, 
                        title, 
                        recipe, 
                        author, 
                        is_enabled
                      FROM
                        ". $this->db_table ."
                    WHERE 
                       recipe_id = ?
                    LIMIT 0,1";
            $stmt = $this->conn->prepare($sqlQuery);
            $stmt->bindParam(1, $this->recipe_id);
            $stmt->execute();
            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $this->title = $dataRow['title'];
            $this->recipe = $dataRow['recipe'];
            $this->author = $dataRow['author'];
            $this->is_enabled = $dataRow['is_enabled'];
        }        
        // UPDATE
        public function updateRecipe(){
            $sqlQuery = "UPDATE
                        ". $this->db_table ."
                    SET
                        title = :title, 
                        recipe = :recipe, 
                        author = :author, 
                        is_enabled = :is_enabled
                    WHERE 
                        recipe_id = :recipe_id";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            // bind data
            $stmt->bindParam(":title", $this->title);
            $stmt->bindParam(":recipe", $this->recipe);
            $stmt->bindParam(":author", $this->author);
            $stmt->bindParam(":is_enabled", $this->is_enabled);
            $stmt->bindParam(":recipe_id", $this->recipe_id);
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }
        // DELETE
        function deleteRecipe(){
            $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE recipe_id = ?";
            $stmt = $this->conn->prepare($sqlQuery);

            $stmt->bindParam(1, $this->recipe_id);
        
            if($stmt->execute()){
                return true;
            }
            return false;
        }
    }
?>
