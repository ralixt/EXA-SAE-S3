<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    
    include_once '../config/database.php';
    include_once '../class/recipes.php';
    
    $database = new Database();
    $db = $database->getConnection();

    $item = new Recipe($db);

    //$item->recipe_id = isset($_GET['recipe_id']) ? $_GET['recipe_id'] : die();
  
    $item->updateRecipe();
    $data = json_decode(file_get_contents("php://input"));

    
    $item->title = $data->title;
    $item->recipe = $data->recipe;
    $item->author = $data->author;
    $item->is_enabled = $data->is_enabled;
    
    
    if($item->updateRecipe()){
        echo 'Recipe updated successfully.';
    } else{
        echo 'Recipe could not be updated.';
    }
?>
