<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../config/database.php';
    include_once '../class/recipes.php';

    $database = new Database();
    $db = $database->getConnection();

    $item = new Recipe($db);

    $item->recipe_id = isset($_GET['recipe_id']) ? $_GET['recipe_id'] : die();
  
    $item->getSingleRecipe();
    
    if($item->title != null){
        // create array
        $emp_arr = array(
            "recipe_id" =>  $item->recipe_id,
            "title" => $item->title,
            "recipe" => $item->recipe,
            "author" => $item->author,
            "is_enabled" => $item->is_enabled
        );
      
        http_response_code(200);
        echo json_encode($emp_arr);
    }
      
    else{
        http_response_code(404);
        echo json_encode("Recipe not found.");
    }
?>
