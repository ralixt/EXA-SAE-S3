<?php

include_once('config.php');


$name=$_POST['name'];
$adress=$_POST['address'];
$salary=$_POST['salary'];
$id=$_POST['id'];

$update=$pdo->prepare('Update employees Set name=:name,address=:address,salary=:salary where id=:id ');
$update->execute([
'name'=> $name,
'address'=>$adress,
'salary'=>$salary,
'id'=>$id
]);

header('location:index.php')


?>