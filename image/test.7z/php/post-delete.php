<?php
include_once('config.php');

$id=$_POST['id'];

$supression=$pdo->prepare('DELETE  FROM employees WHERE id=:id');
$supression->execute([
    'id'=>$id,
]);

header('location:index.php');
?>