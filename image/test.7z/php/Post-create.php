<?php

include_once('config.php');


$name=$_POST['name'];
$adress=$_POST['address'];
$salary=$_POST['salary'];
$ajoutinfo=$pdo->prepare('INSERT INTO employees (name,address,salary) VALUES( :name,:adress ,:salary)');
$ajoutinfo->execute([

'name'=> $name,
'adress'=> $adress,
'salary'=>$salary

]);

header('location:index.php')


?>